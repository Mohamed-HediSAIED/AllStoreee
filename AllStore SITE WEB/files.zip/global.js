/* ALLSTORE 24/7 — Global JS */
(function(){
  'use strict';

  /* ── Cursor ─────────────────────────────────────────────────── */
  const dot=document.createElement('div'); dot.id='cur-dot';
  const ring=document.createElement('div'); ring.id='cur-ring';
  document.body.append(dot,ring);
  let mx=0,my=0,rx=0,ry=0;
  document.addEventListener('mousemove',e=>{mx=e.clientX;my=e.clientY});
  const hEls='a,button,.chip,.opt-item,.size-chip,.color-chip,.tab-btn,.pc,.ac,.arrow,.btn,.btn-primary,.btn-back,.wa-btn,.wa-btn-c,.wl-btn,#wl-nav-btn,.wl-sourcer,.wl-close,.wl-remove';
  document.addEventListener('mouseover',e=>{if(e.target.closest(hEls))document.body.classList.add('cur-h')});
  document.addEventListener('mouseout',e=>{if(e.target.closest(hEls))document.body.classList.remove('cur-h')});
  (function loop(){requestAnimationFrame(loop);rx+=(mx-rx)*.12;ry+=(my-ry)*.12;
    dot.style.transform=`translate(${mx}px,${my}px) translate(-50%,-50%)`;
    ring.style.transform=`translate(${rx}px,${ry}px) translate(-50%,-50%)`})();

  /* ── Nav hide/show ──────────────────────────────────────────── */
  const header=document.querySelector('header');
  let last=0;
  window.addEventListener('scroll',()=>{
    const s=scrollY;
    if(s>80)header.classList.add('scrolled');else header.classList.remove('scrolled');
    if(s>last+6&&s>100)header.classList.add('up');else if(s<last-6)header.classList.remove('up');
    last=s;
  },{passive:true});

  /* ── Scroll reveal ──────────────────────────────────────────── */
  const io=new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('on');io.unobserve(e.target)}});
  },{threshold:.1,rootMargin:'0px 0px -36px 0px'});
  document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

  /* ── 3D card tilt ───────────────────────────────────────────── */
  document.querySelectorAll('.pc,.ac').forEach(c=>{
    c.addEventListener('mousemove',e=>{
      const r=c.getBoundingClientRect();
      const x=(e.clientX-r.left)/r.width-.5;
      const y=(e.clientY-r.top)/r.height-.5;
      c.style.transform=`perspective(900px) rotateY(${x*9}deg) rotateX(${-y*9}deg) scale(1.02)`;
    });
    c.addEventListener('mouseleave',()=>{
      c.style.transition='transform .6s cubic-bezier(0.16,1,0.3,1),box-shadow .5s';
      c.style.transform='';
      setTimeout(()=>c.style.transition='',600);
    });
  });

  /* ── Page transitions ───────────────────────────────────────── */
  const wipe=document.createElement('div'); wipe.id='wipe';
  document.body.prepend(wipe);
  wipe.classList.add('out');
  wipe.addEventListener('animationend',()=>wipe.className='',{once:true});
  document.addEventListener('click',e=>{
    const a=e.target.closest('a[href]');
    if(!a)return;
    if(a.hostname!==location.hostname||a.pathname===location.pathname||
       a.getAttribute('href').startsWith('#')||a.getAttribute('href').startsWith('mailto')||
       a.getAttribute('href').startsWith('tel')||a.getAttribute('href').startsWith('https://wa.me')||
       a.hasAttribute('download')||a.target==='_blank')return;
    e.preventDefault();
    const url=a.href;
    wipe.className='';void wipe.offsetWidth;wipe.classList.add('in');
    wipe.addEventListener('animationend',()=>{window.location=url},{once:true});
  });

  /* ── Globals ────────────────────────────────────────────────── */
  window.scrollSection=function(btn,dir){
    const ps=btn.closest('.sw').querySelector('.ps');
    ps.scrollBy({left:dir*400,behavior:'smooth'});
  };
  window.switchTab=function(id){
    document.querySelectorAll('.tab-panel').forEach(p=>p.style.display='none');
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    document.getElementById('tab-'+id).style.display='';
    document.querySelector(`[onclick="switchTab('${id}')"]`).classList.add('active');
  };

  /* ══════════════════════════════════════════════════════════════
     PANIER — Cart persistant (localStorage)
  ══════════════════════════════════════════════════════════════ */
  const CART_KEY='als_cart';
  const getCart=()=>{try{return JSON.parse(localStorage.getItem(CART_KEY))||[]}catch{return[]}};
  const saveCart=items=>localStorage.setItem(CART_KEY,JSON.stringify(items));
  const inCart=id=>getCart().some(i=>i.id===id);

  window.addToCart=function(id,brand,name,img,price){
    let cart=getCart();
    if(!inCart(id)){cart.push({id,brand,name,img,price});saveCart(cart)}
    updateCartUI();
    showToast(name+' ajouté au panier');
  };

  window.removeFromCart=function(id){
    saveCart(getCart().filter(i=>i.id!==id));
    updateCartUI();
    if(document.getElementById('cart-items'))renderCartPage();
  };

  function updateCartUI(){
    const cnt=document.getElementById('cart-count');
    const c=getCart();
    if(cnt){cnt.textContent=c.length;cnt.style.display=c.length?'flex':'none'}
  }

  window.renderCartPage=function(){
    const wlEl=document.getElementById('wishlist-on-cart');
    const cartEl=document.getElementById('cart-items');
    if(wlEl){
      const wl=getWL();
      if(!wl.length){wlEl.innerHTML='<p class="wl-empty">Votre liste de souhait est vide.</p>';return;}
      wlEl.innerHTML=wl.map(i=>`
        <div class="cart-row">
          <div class="cart-img"><img src="${i.img}" alt="${i.name}"></div>
          <div class="cart-info"><span class="cart-brand">${i.brand}</span><span class="cart-name">${i.name}</span></div>
          <button class="btn-add-cart" onclick="addToCart('${i.id}','${i.brand}','${i.name}','${i.img}','')">
            ${inCart(i.id)?'✓ Dans le panier':'Ajouter au panier'}
          </button>
        </div>`).join('');
    }
    if(cartEl){
      const cart=getCart();
      if(!cart.length){cartEl.innerHTML='<p class="wl-empty">Votre panier est vide.</p>';return;}
      cartEl.innerHTML=cart.map(i=>`
        <div class="cart-row">
          <div class="cart-img"><img src="${i.img}" alt="${i.name}"></div>
          <div class="cart-info"><span class="cart-brand">${i.brand}</span><span class="cart-name">${i.name}</span>${i.price?`<span class="cart-price">${i.price}</span>`:''}</div>
          <button class="btn-remove-cart" onclick="removeFromCart('${i.id}')">&#x2715; Retirer</button>
        </div>`).join('');
    }
  };

  /* ══════════════════════════════════════════════════════════════
     WISHLIST — Liste de souhait persistante (localStorage)
  ══════════════════════════════════════════════════════════════ */
  const WL_KEY='als_wishlist';
  const getWL=()=>{try{return JSON.parse(localStorage.getItem(WL_KEY))||[]}catch{return[]}};
  const saveWL=items=>localStorage.setItem(WL_KEY,JSON.stringify(items));
  const inWL=id=>getWL().some(i=>i.id===id);

  function toggleWL(id,brand,name,img){
    let wl=getWL();
    const idx=wl.findIndex(i=>i.id===id);
    if(idx>-1)wl.splice(idx,1);else wl.push({id,brand,name,img});
    saveWL(wl);updateWLUI();
    return idx===-1;
  }

  function updateWLUI(){
    const wl=getWL();
    const cnt=document.getElementById('wl-count');
    if(cnt){cnt.textContent=wl.length;cnt.style.display=wl.length?'flex':'none'}
    const el=document.getElementById('wl-items');
    if(!el)return;
    if(!wl.length){
      el.innerHTML='<p class="wl-empty">Votre liste de souhait est vide.<br>Cliquez sur \u2764 sur une pi\u00e8ce pour l\'ajouter.</p>';
      return;
    }
    el.innerHTML=wl.map(i=>`
      <div class="wl-item">
        <div class="wl-item-img"><img src="${i.img}" alt="${i.name}"></div>
        <div class="wl-item-info">
          <span class="wl-item-brand">${i.brand}</span>
          <span class="wl-item-name">${i.name}</span>
        </div>
        <div class="wl-item-actions">
          <a href="assistant.html" class="wl-sourcer">Sourcer \u2192</a>
          <button class="wl-remove" onclick="window._wlRemove('${i.id}')">&#x2715;</button>
        </div>
      </div>`).join('');
  }

  window._wlRemove=function(id){
    saveWL(getWL().filter(i=>i.id!==id));
    updateWLUI();
    document.querySelectorAll('.wl-btn').forEach(btn=>{
      const card=btn.closest('.pc');if(!card)return;
      const bid=((card.querySelector('.ct')||{textContent:''}).textContent+'_'+(card.querySelector('.cn')||{textContent:''}).textContent).trim().replace(/\s+/g,'_').toLowerCase();
      btn.classList.toggle('wl-active',inWL(bid));
    });
  };

  window._toggleWLDrawer=function(){
    const d=document.getElementById('wl-drawer');
    const ov=document.getElementById('wl-overlay');
    if(d){d.classList.toggle('open');ov&&ov.classList.toggle('open')}
    updateWLUI();
  };

  // Injecter le bouton Liste de souhait dans la nav + le tiroir
  (function(){
    const nav=document.querySelector('nav');if(!nav)return;
    // Bouton liste de souhait
    const btn=document.createElement('button');
    btn.id='wl-nav-btn';btn.setAttribute('aria-label','Liste de souhait');
    btn.onclick=window._toggleWLDrawer;
    btn.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><span id="wl-count" style="display:none">0</span>`;
    nav.appendChild(btn);
    // Bouton panier
    const cartBtn=document.createElement('a');
    cartBtn.id='cart-nav-btn';cartBtn.href='panier.html';cartBtn.setAttribute('aria-label','Mon panier');
    cartBtn.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 001.99 1.61h9.72a2 2 0 001.99-1.61L23 6H6"/></svg><span id="cart-count" style="display:none">0</span>`;
    nav.appendChild(cartBtn);
    const ov=document.createElement('div');ov.id='wl-overlay';ov.onclick=window._toggleWLDrawer;
    const dr=document.createElement('div');dr.id='wl-drawer';
    dr.innerHTML=`<div class="wl-drawer-inner"><div class="wl-drawer-head"><span>Liste de souhait</span><button class="wl-close" onclick="window._toggleWLDrawer()">\u2715</button></div><div id="wl-items"></div><a href="panier.html" class="wl-cta-all">Voir le panier \u2192</a></div>`;
    document.body.append(ov,dr);
    updateWLUI();
    updateCartUI();
  })();

  // Injecter le badge "Rare" sur les cartes sombres
  document.querySelectorAll('.pc.dk').forEach(card=>{
    const badge=document.createElement('span');
    badge.className='rare-badge';
    badge.textContent='Rare';
    card.appendChild(badge);
  });

  // Injecter les boutons coeur sur chaque carte produit
  document.querySelectorAll('.pc').forEach(card=>{
    const brand=((card.querySelector('.ct')||{textContent:''}).textContent).trim();
    const name=((card.querySelector('.cn')||{textContent:''}).textContent).trim();
    const img=(card.querySelector('.ci img')||{getAttribute:()=>''}).getAttribute('src')||'';
    const id=(brand+'_'+name).replace(/\s+/g,'_').toLowerCase();
    const btn=document.createElement('button');
    btn.className='wl-btn'+(inWL(id)?' wl-active':'');
    btn.setAttribute('aria-label','Ajouter à la liste de souhait');
    btn.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`;
    btn.addEventListener('click',e=>{
      e.preventDefault();e.stopPropagation();
      const added=toggleWL(id,brand,name,img);
      btn.classList.toggle('wl-active',added);
      showToast(added?name+' ajout\u00e9 \u00e0 la liste de souhait':name+' retir\u00e9 de la liste de souhait');
    });
    card.appendChild(btn);
  });

  /* ── Toast notification ─────────────────────────────────────── */
  function showToast(msg){
    let t=document.getElementById('wl-toast');
    if(!t){t=document.createElement('div');t.id='wl-toast';document.body.appendChild(t)}
    t.textContent=msg;t.classList.add('show');
    clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove('show'),2500);
  }

  /* ══════════════════════════════════════════════════════════════
     LIVE TICKER — Activite en temps reel
  ══════════════════════════════════════════════════════════════ */
  (function(){
    const events=[
      'Rolex Daytona trouv\u00e9e \u2014 Paris, \u00e0 l\'instant',
      'Air Jordan 1 Chicago \u2014 sour\u00e7age en cours',
      'Commande livr\u00e9e \u2014 Audemars Piguet \u00b7 Bruxelles',
      'Nouveau sour\u00e7age \u2014 Chanel Coco Mademoiselle',
      'Expert disponible \u00b7 R\u00e9ponse < 2 min',
      'Stone Island Ghost \u2014 stock confirm\u00e9',
      'Adidas Samba OG \u00b7 stock confirm\u00e9 Tokyo',
      'Service Or actif \u00b7 24h/24, 7j/7',
    ];
    const ticker=document.createElement('div');ticker.id='live-ticker';
    const dot=document.createElement('span');dot.className='lt-dot';
    const text=document.createElement('span');text.id='lt-text';
    ticker.append(dot,text);
    document.body.appendChild(ticker);
    let idx=Math.floor(Math.random()*events.length);
    function next(){
      text.style.opacity='0';
      setTimeout(()=>{text.textContent=events[idx++%events.length];text.style.opacity='1'},350);
    }
    next();setInterval(next,4500);
  })();

  /* ══════════════════════════════════════════════════════════════
     PERSONNALISATION — Greeting avec prenom memorise
  ══════════════════════════════════════════════════════════════ */
  (function(){
    const name=localStorage.getItem('als_name');
    if(!name)return;
    const ey=document.querySelector('.hero-eyebrow');
    if(ey)ey.textContent='Bienvenue, '+name+' \u2014 Sourcing d\'Exception';
  })();

  /* ══════════════════════════════════════════════════════════════
     WHATSAPP FLOATING BUTTON
  ══════════════════════════════════════════════════════════════ */
  (function(){
    const wa=document.createElement('a');
    wa.id='wa-float';
    wa.href='https://wa.me/33626587984';
    wa.target='_blank';
    wa.rel='noopener noreferrer';
    wa.setAttribute('aria-label','Chat avec un expert');
    wa.innerHTML=`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.136.558 4.14 1.535 5.878L.057 23.5l5.763-1.512A11.943 11.943 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.87 0-3.63-.5-5.15-1.38l-.37-.22-3.82 1 1.02-3.72-.24-.38A9.96 9.96 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>`;
    document.body.appendChild(wa);

    const tip=document.createElement('div');
    tip.id='wa-float-tip';
    tip.textContent='Chat avec un expert';
    document.body.appendChild(tip);
  })();

  /* ══════════════════════════════════════════════════════════════
     HAMBURGER MOBILE MENU
  ══════════════════════════════════════════════════════════════ */
  (function(){
    const nav=document.querySelector('nav');
    if(!nav)return;
    const ham=document.createElement('button');
    ham.id='ham-btn';
    ham.setAttribute('aria-label','Ouvrir le menu');
    ham.innerHTML='<span></span><span></span><span></span>';
    nav.appendChild(ham);
    ham.addEventListener('click',()=>{
      const open=document.body.classList.toggle('nav-open');
      document.body.style.overflow=open?'hidden':'';
      ham.setAttribute('aria-label',open?'Fermer':'Ouvrir le menu');
    });
    document.querySelectorAll('.nav-links a').forEach(a=>{
      a.addEventListener('click',()=>{
        document.body.classList.remove('nav-open');
        document.body.style.overflow='';
      });
    });
    // Close on overlay click (touch outside)
    document.addEventListener('click',e=>{
      if(!document.body.classList.contains('nav-open'))return;
      if(!e.target.closest('nav'))return;
      if(e.target.closest('.nav-links')||e.target.closest('#ham-btn'))return;
    });
  })();

  /* BRAND MARQUEE — désactivé */

  /* ══════════════════════════════════════════════════════════════
     MAGNETIC BUTTONS
  ══════════════════════════════════════════════════════════════ */
  (function(){
    if(window.matchMedia('(max-width:768px)').matches)return;
    document.querySelectorAll('.btn,.wa-btn').forEach(btn=>{
      btn.addEventListener('mousemove',e=>{
        const r=btn.getBoundingClientRect();
        const x=(e.clientX-r.left-r.width/2)*.28;
        const y=(e.clientY-r.top-r.height/2)*.38;
        btn.style.transition='transform .1s,box-shadow .15s';
        btn.style.transform=`translate(${x}px,${y}px) scale(1.04)`;
      });
      btn.addEventListener('mouseleave',()=>{
        btn.style.transition='transform .65s cubic-bezier(.16,1,.3,1),box-shadow .4s';
        btn.style.transform='';
      });
    });
  })();

  /* ══════════════════════════════════════════════════════════════
     HERO PARALLAX (desktop only)
  ══════════════════════════════════════════════════════════════ */
  (function(){
    if(window.matchMedia('(max-width:768px)').matches)return;
    const hero=document.querySelector('.hero');
    if(!hero)return;
    let ready=false;
    setTimeout(()=>{ready=true;},1300);
    const map=[
      ['.hero-badge-live',-.06],['.hero-eyebrow',-.10],
      ['h1',-.16],['.hero-ornament',-.13],
      ['.hero-sub',-.09],['.hero-stats',-.05],
    ].map(([sel,spd])=>[hero.querySelector(sel),spd]).filter(([el])=>el);
    const heroH=()=>hero.offsetHeight;
    window.addEventListener('scroll',()=>{
      if(!ready)return;
      const s=window.scrollY;
      if(s>heroH()){map.forEach(([el])=>{el.style.transform='';});return;}
      map.forEach(([el,spd])=>{el.style.transform=`translateY(${s*spd}px)`;});
    },{passive:true});
  })();

  /* ══════════════════════════════════════════════════════════════
     CARD SPOTLIGHT (mouse glow on dark cards)
  ══════════════════════════════════════════════════════════════ */
  (function(){
    if(window.matchMedia('(max-width:768px)').matches)return;
    document.querySelectorAll('.pc.dk').forEach(card=>{
      const spot=document.createElement('div');
      spot.className='pc-spotlight';
      card.appendChild(spot);
      card.addEventListener('mousemove',e=>{
        const r=card.getBoundingClientRect();
        spot.style.cssText+=`left:${e.clientX-r.left}px;top:${e.clientY-r.top}px;opacity:1`;
      });
      card.addEventListener('mouseleave',()=>{spot.style.opacity='0';});
    });
  })();

  /* ══════════════════════════════════════════════════════════════
     GRADIENT TEXT — headings clés
  ══════════════════════════════════════════════════════════════ */
  (function(){
    document.querySelectorAll('.hero h1 em,.page-hero h1 em,.ap-hero h1 em').forEach(el=>el.classList.add('grad-text'));
  })();

  /* ══════════════════════════════════════════════════════════════
     FOOTER SOCIAL LINKS (injecté sur toutes les pages)
  ══════════════════════════════════════════════════════════════ */
  (function(){
    document.querySelectorAll('.foot-inner').forEach(fi=>{
      if(fi.querySelector('.foot-social'))return;
      const s=document.createElement('div');
      s.className='foot-social';
      s.innerHTML=`
        <a href="https://www.instagram.com/allstore.tm" target="_blank" rel="noopener" aria-label="Instagram">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16">
            <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
          </svg>
        </a>
        <a href="https://www.tiktok.com/@allstore247.co" target="_blank" rel="noopener" aria-label="TikTok">
          <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14">
            <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.27 8.27 0 0 0 4.84 1.55V6.79a4.85 4.85 0 0 1-1.07-.1z"/>
          </svg>
        </a>
        <a href="https://wa.me/33626587984" target="_blank" rel="noopener" aria-label="WhatsApp">
          <svg viewBox="0 0 24 24" fill="currentColor" width="15" height="15">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.136.558 4.14 1.535 5.878L.057 23.5l5.763-1.512A11.943 11.943 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.87 0-3.63-.5-5.15-1.38l-.37-.22-3.82 1 1.02-3.72-.24-.38A9.96 9.96 0 0 1 2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
          </svg>
        </a>`;
      fi.appendChild(s);
    });
  })();

  /* ══════════════════════════════════════════════════════════════
     COUNTER ANIMATION — .stats-band et .foot-stats-band
  ══════════════════════════════════════════════════════════════ */
  (function(){
    const targets=[
      {sel:'.sn',extract:el=>{
        const txt=el.textContent;
        const m=txt.match(/[\d]+/);
        return m?parseInt(m[0]):null;
      },render:(el,v)=>{
        el.innerHTML=el.innerHTML.replace(/[\d]+/,v);
      }},
    ];
    const io2=new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(!e.isIntersecting)return;
        io2.unobserve(e.target);
        const el=e.target;
        const target=parseInt(el.dataset.countTo||el.textContent.match(/[\d]+/)?.[0])||0;
        if(!target)return;
        const dur=1800,start=performance.now();
        const orig=el.innerHTML;
        (function step(now){
          const p=Math.min((now-start)/dur,1);
          const ease=1-Math.pow(1-p,3);
          const val=Math.round(ease*target);
          el.innerHTML=orig.replace(/[\d]+/,val);
          if(p<1)requestAnimationFrame(step);
        })(start);
      });
    },{threshold:.4});
    document.querySelectorAll('.sn').forEach(el=>io2.observe(el));
  })();

})();
